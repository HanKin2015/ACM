#
#	configuration variables for the example

## Main application file
MAIN = motifs
DEPH = $(EXSNAPADV)/subgraphenum.h $(EXSNAPADV)/graphcounter.h
DEPCPP = $(EXSNAPADV)/subgraphenum.cpp $(EXSNAPADV)/graphcounter.cpp

